﻿using Libaray_Management_System.Data;
using Libaray_Management_System.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Libaray_Management_System.Repos.BookRepo
{
    public class BookRepo : IBookRepo
    {
        private readonly LibarayManagementContext _Context;
        public BookRepo(LibarayManagementContext context)
        {
            _Context = context;
        }
        public async Task AddBook(Book book)
        {
          await  _Context.Books.AddAsync(book);
          await  _Context.SaveChangesAsync();
        }

        public async Task<Book> DeleteBook(int id, Book book)
        {
            var DeleteBook = await _Context.Books.FirstOrDefaultAsync(b => b.BookId == id);
            _Context.Books.Remove(DeleteBook);
            await _Context.SaveChangesAsync();
            return book;
        }

        public async Task<IEnumerable<Book>> GetAllBooks()
        {
            var AllBooks = await _Context.Books.Include(r => r.Reservations).Include(tr => tr.BorrowTransactions).ToListAsync();
            return AllBooks;
        }

        public async Task<Book> GetBookDetails(int id)
        {
            var showDeteials = await _Context.Books.FirstOrDefaultAsync(b => b.BookId == id);
            return showDeteials;
        }

        public Book UpdateBook(int id, Book book)
        {
            throw new NotImplementedException();
        }
    }
}
