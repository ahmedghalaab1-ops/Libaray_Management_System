﻿using Libaray_Management_System.Models;

namespace Libaray_Management_System.Repos.BookRepo
{
    public interface IBookRepo
    {
        Task<IEnumerable<Book>> GetAllBooks();
        Task<Book> GetBookDetails(int id);
        Task AddBook(Book book);
        void UpdateBook(int id, Book book);
        void DeleteBook(int id, Book book);

    }
}
