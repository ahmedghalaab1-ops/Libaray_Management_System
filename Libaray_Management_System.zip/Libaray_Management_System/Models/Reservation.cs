﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Libaray_Management_System.Models
{
    public enum StatusTypee { Active, Fulfilled, Cancelled, Expired }
    public class Reservation
    {
        [Key]
        public int ReservationId {  get; set; }
        [ForeignKey(nameof(MemberId))]
        public Member Member { get; set; }
        public int MemberId {  get; set; }
        [ForeignKey(nameof(BookId))]
        public Book Book { get; set; }
        public int BookId {  get; set; }
        public DateTime ReservationDate {  get; set; }
        public DateTime ExpiryDate {  get; set; }
        public StatusTypee Status {  get; set; }
        public bool NotificationSent {  get; set; }

    }
}
