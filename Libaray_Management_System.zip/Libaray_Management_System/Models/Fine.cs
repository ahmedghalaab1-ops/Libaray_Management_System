﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Libaray_Management_System.Models
{
    public enum StatusTypeee { Pending, Paid, Waived }
    public class Fine
    {
        [Key]
         public int FineId { get; set; }

        [ForeignKey(nameof(MemberId))]
        public Member Member { get; set; }
         public int MemberId {  get; set; }

        [AllowNull]
        [ForeignKey(nameof(TransactionId))]
        public BorrowTransaction BorrowTransaction { get; set; }
         public int TransactionId {  get; set; }

         public decimal Amount {  get; set; }
         public string Reason {  get; set; }
         public DateTime IssueDate {  get; set; }
        [AllowNull]
         public DateTime PaymentDate {  get; set; }
         public StatusTypeee Status {  get; set; }

    }
}
