﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Libaray_Management_System.Models
{
    public class Book
    {
        [Key]
        public int BookId {  get; set; }

        [Required]
        [Range(13,13,ErrorMessage ="The ISBN Range must be 13 Chars!!")]
        public string? ISBN {  get; set; } //unique, 13 chars

        [StringLength(200)]
        public string Title {  get; set; }

        [Required]
        [StringLength(100)]
        public string Author { get; set;}

        [StringLength(100)]
        public string Publisher {  get; set; }
        public int PublicationYear {  get; set; }

        [ForeignKey(nameof(CategoryId))]
        public Category Category { get; set; }
        public int CategoryId {  get; set; }

        [StringLength(1000)]
        public string Description {  get; set; }
        public string CoverImageUrl {  get; set; }
        public int TotalCopies {  get; set; }
        public int AvailableCopies {  get; set; }
        public string ShelfLocation {  get; set; }
        public bool IsActive {  get; set; }
        public DateTime CreatedDate {  get; set; }

        
        public ICollection<BorrowTransaction> BorrowTransactions { get; set; }
        public ICollection<Reservation> Reservations { get; set; }
    }
}
