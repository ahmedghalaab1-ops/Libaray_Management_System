﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Libaray_Management_System.Models
{
    public enum StatusType { Active, Returned, Overdue }
    public class BorrowTransaction
    {
        [Key]
        public int TransactionId { get; set; }
        public int MemberId { get; set; }
        [ForeignKey(nameof(MemberId))]
        public Member Member { get; set; }

        [ForeignKey(nameof(BookId))]
        public Book Book { get; set; }
        public int BookId {  get; set; }
        public DateTime BorrowDate {  get; set; }
        public DateTime DueDate {  get; set; }
        [AllowNull]
        public DateTime ReturnDate {  get; set; }
        public StatusType Status { get; set; }
        public int RenewalCount { get; set; } = 0;
        public decimal LateFee {  get; set; }
        public bool IsFeePaid{ get; set; }


        public ICollection<Fine> Fines { get;set; }
    }
}
