﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;

namespace Libaray_Management_System.Models
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }
        [Required]
        [StringLength(50)]
        public string? Name {  get; set; } //unique 
        [StringLength(200)]
        public string Description {  get; set; }
        public ICollection<Book> Books { get; set; }


    }
}
