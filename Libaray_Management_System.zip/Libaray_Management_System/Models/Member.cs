﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Principal;

namespace Libaray_Management_System.Models
{
    public enum RoleType { Admin,User}
    public class Member
    {
        [Key]
        public int MemberId {  get; set; }
        public string MembershipNumber { get; set; } //unique
        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }
        [Required]
        [StringLength(50)]
        public string LastName { get; set; }
        [Required]
        public string Email {  get; set; }
        public string PhoneNumber { get; set; }
        [StringLength(200)]
        public string Address { get; set;}
        public DateTime MembershipDate {  get; set;}
        public DateTime MembershipExpiryDate {  get; set;}
        public bool IsActive {  get; set;}
        public int MaxBooksAllowed = 5;
        public decimal OutstandingFees {  get; set;}

        public ICollection<Fine> Fines { get; set;}
        public ICollection<Reservation> Reservations { get; set; }
        public ICollection<BorrowTransaction> BorrowTransactions { get; set; }

        public RoleType RoleType { get; set;}

    }
}
